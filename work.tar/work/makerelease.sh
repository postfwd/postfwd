#!/bin/bash

CHANGE=0
REPO=/git/postfwd
BACK=/root/git_postfwd_work.tar

# warn and stop if debug statements found
if [ -n "`grep DBG postfwd3`" ]; then
	( echo; echo "DBG Statements found - please check code!"; echo; grep -n DBG postfwd3; echo ) >&2
	exit 1
else
	echo
	# pre-cleanup
	rm -f *.temp *.tmp

	# postfwd main binary
	if [ -n "`diff postfwd3 ${REPO}/sbin/postfwd3`" ]; then
		CHANGE=1
		echo "postfwd3 -> ${REPO}/sbin/postfwd3"
		cat postfwd3 >${REPO}/sbin/postfwd3
		echo "RUN: postfwd --stdout --nodaemon -v --v2"
	fi

	# manpage
	pod2man postfwd3 >postfwd3.8.temp
	if [ -n "`diff postfwd3.8.temp ${REPO}/man/man8/postfwd3.8`" ]; then
		CHANGE=1
		echo "postfwd3.8.temp -> ${REPO}/man/man8/postfwd3.8"
		cat postfwd3.8.temp >${REPO}/man/man8/postfwd3.8
	fi

	# text
	pod2text postfwd3 >postfwd3.txt.temp
	if [ -n "`diff postfwd3.txt.temp ${REPO}/doc/postfwd3.txt`" ]; then
		CHANGE=1
		echo "postfwd3.txt.temp -> ${REPO}/doc/postfwd3.txt"
		cat postfwd3.txt.temp >${REPO}/doc/postfwd3.txt
	fi

	# html
	pod2html postfwd3 >postfwd3.html.temp
	if [ -n "`diff postfwd3.html.temp ${REPO}/doc/postfwd3.html`" ]; then
		CHANGE=1
		echo "postfwd3.html.temp -> ${REPO}/doc/postfwd3.html"
		cat postfwd3.html.temp >${REPO}/doc/postfwd3.html
	fi

	# refresh git repo
	if [ $CHANGE -gt 0 ]; then
		echo; echo "Change detected, saving work to ${BACK}..."
		( cd ${REPO} && tar -cf ${BACK} work && ls -l ${BACK} )
		echo; echo "Updating git repo..."
		( cd ${REPO} && git add --all )
		echo "RUN: git push"
		echo; echo "Updating p:test docker image..."
		docker build --pull -t p:test ${REPO}/work
		echo "RUN: docker run --rm -it -e PROG=postfwd3 p:test"
	fi

	# post-cleanup
	rm -f *.temp *.tmp
	echo
fi

